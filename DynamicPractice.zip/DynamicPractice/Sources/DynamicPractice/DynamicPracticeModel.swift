// The Swift Programming Language
// https://docs.swift.org/swift-book

public struct DynamicPracticeModel {
    public init() { }
    
    public func saySomething() -> String {
        "Hello"
    }
}
